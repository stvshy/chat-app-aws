def handler(event, context):
    return {
        'statusCode': 200,
        'body': 'This is a dummy handler'
    }